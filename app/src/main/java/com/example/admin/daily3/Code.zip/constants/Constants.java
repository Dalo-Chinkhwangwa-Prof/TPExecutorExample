package com.example.admin.daily3.constants;

public class Constants {

    public class Globals
    {
        public int NUMBER_OF_CORES = Runtime.getRuntime().availableProcessors();
    }

}
